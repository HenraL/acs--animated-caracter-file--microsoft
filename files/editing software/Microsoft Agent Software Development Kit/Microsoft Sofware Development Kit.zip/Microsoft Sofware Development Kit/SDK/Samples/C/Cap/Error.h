#ifndef _Error_h_
#define _Error_h_


void SystemError(HWND hWndParent, HRESULT hRes, BOOL bWarning);


#endif