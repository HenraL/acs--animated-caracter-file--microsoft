//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by cap.rc
//
#define IDS_COMMAND_PROPERTIES          1
#define IDS_ANIMATIONS_LABEL            2
#define IDD_DIALOG1                     101
#define IDD_CAP                         101
#define IDR_MENU                        110
#define IDI_APP                         153
#define IDR_ACCELERATORS                165
#define IDD_ABOUT                       178
#define IDC_ANIMATIONS                  1000
#define IDC_PLAY                        1001
#define IDC_STOP                        1002
#define IDC_SPEAKTEXT                   1003
#define IDC_SPEAK                       1004
#define IDC_BALLOON_USE                 1005
#define IDC_BALLOON_SIZETOTEXT          1006
#define IDC_BALLOON_AUTOPACE            1007
#define IDC_BALLOON_AUTOHIDE            1008
#define IDC_MOVE_X                      1009
#define IDC_MOVE_Y                      1010
#define IDC_MOVE                        1011
#define IDC_STOPBEFOREPLAY              1012
#define IDC_ANIMATIONS_LABEL            1014
#define IDC_SFX                         1015
#define IDC_SPEECHOUTPUT_LABEL          1016
#define IDC_POSITION_LABEL              1017
#define IDC_X_LABEL                     1018
#define IDC_Y_LABEL                     1019
#define IDC_ICONPOS                     1108
#define IDC_VERSION                     1115
#define IDC_AGENTVERSION                1116
#define ID_FILE_EXIT                    40001
#define ID_HELP_ABOUT                   40002
#define ID_FILE_OPENCHARACTER           40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
