Hello World (C++) Sample for Microsoft Agent
--------------------------------------------

*** Required components ***

1. This sample requires the Microsoft Agent include files.  These files
along with the addition *_i.c files should be copied to the Visual C++ 
Include directory.

2. This sample tries to load a default character from the 
%windows%\msagent\chars directory. If no default character
can be loaded, it attempts to load Genie.acs from the 
%program files%\Microsoft Agent\Characters directory.


*** To run the sample ***

1. Start up Microsoft Visual C++.  From the File menu, select Open Workspace.
Navigate to the folder containing this Readme file.  Select the project file
(hello.dsp) for this sample.  Click Open.

2. From the Build menu, select Execute.  When prompted to build the exe file,
click Yes.
