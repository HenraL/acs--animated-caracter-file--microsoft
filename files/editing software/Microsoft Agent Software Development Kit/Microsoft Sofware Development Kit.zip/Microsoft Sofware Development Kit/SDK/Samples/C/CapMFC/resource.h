//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CapMFC.rc
//
#define IDS_ANIMATIONS_LABEL            2
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CAPMFC_DIALOG               102
#define IDS_COMMAND_PROPERTIES          102
#define IDR_MAINFRAME                   128
#define IDR_MENU                        130
#define IDC_ANIMATIONS                  1000
#define IDC_PLAY                        1001
#define IDC_STOP                        1002
#define IDC_AGENT                       1003
#define IDC_SPEAK                       1004
#define IDC_MOVE                        1005
#define IDC_STOPBEFOREPLAY              1012
#define IDC_ANIMATIONS_LABEL            1014
#define IDC_SFX                         1015
#define IDC_SPEECHOUTPUT_LABEL          1016
#define IDC_EDIT1                       1017
#define IDC_SPEAKTEXT                   1017
#define IDC_BALLOON_USE                 1018
#define IDC_BALLOON_AUTOHIDE            1019
#define IDC_BALLOON_AUTOPACE            1020
#define IDC_BALLOON_SIZETOTEXT          1021
#define IDC_POSITION_LABEL              1022
#define IDC_X_LABEL                     1023
#define IDC_MOVE_X                      1024
#define IDC_MOVE_Y                      1025
#define IDC_VERSION                     1025
#define IDC_Y_LABEL                     1026
#define ID_FILE_EXIT                    32772
#define ID_HELP_ABOUT                   32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
