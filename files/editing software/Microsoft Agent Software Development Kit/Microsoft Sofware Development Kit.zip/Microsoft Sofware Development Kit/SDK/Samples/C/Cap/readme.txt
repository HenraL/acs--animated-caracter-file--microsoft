Microsoft Character Animation Previewer Sample
----------------------------------------------

This sample demonstrates the use of the Microsoft Agent server from a
standard Windows C++ application. The application does not use the MFC or
any other class library. 


*** Required components ***

1. This sample requires the Microsoft Agent include files.  These files
along with the addition *_i.c files should be copied to the Visual C++ 
Include directory.


*** To run the sample ***

1. Start up Microsoft Visual C++.  From the File menu, select Open Workspace.
Navigate to the folder containing this Readme file.  Select the workspace file
(Cap.dsp) for this sample.  Click Open.

2. From the Build menu, select Execute.  When prompted to build the exe file,
click Yes.