#ifndef _HelloAgent2_h_
#define _HelloAgent2_h_


#ifndef STRICT
#define STRICT
#endif


#include <windows.h>
#include <tchar.h>
#include "AgtSvr.h"


#endif
