CapJ (Character Animation Previewer - Java)
-----------------------------------------------

*** Required components ***

1. This sample requires the Microsoft Agent Core Components and the
TruVoice Text-To-Speech Engine.  These should be installed before
running this sample.

2. This sample demonstrates the use of the Microsoft Agent
control from Visual J++ 6.0 Java. The sample uses the Windows
Foundation Class Library (WFC).


*** To run the sample ***

1. Start up Microsoft Visual J++ 6.0.  From the File menu, select Open Project.
Navigate to the folder containing this Readme file.  Select the project file
(CapJ.sln) for this sample.  Click Open.

2. From the Project menu, select Add COM Wrapper. Scroll down and select the
Microsoft Agent Control 2.0. Click OK.

3. Run the application by clicking the Play button (or by selecting Start from
the Debug menu)
