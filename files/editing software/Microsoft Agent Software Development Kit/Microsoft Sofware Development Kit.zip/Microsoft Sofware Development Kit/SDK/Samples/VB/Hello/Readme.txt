Hello World (VB) Sample for Microsoft Agent V2
----------------------------------------------

*** Required components ***

1. This sample requires the Microsoft Agent Core Components,
version 2, and the Lernout & Hauspie� TruVoice Text-To-Speech Engine.
These should be installed before attempting to run this sample.

2. This sample reads character animations from the standard
Agent character path.  The character animation file for Genie
should be installed before attempting to run this sample.


*** To run the sample ***

1. Start up Microsoft Visual Basic.  From the File menu, select
Open Project.  Navigate to the folder containing this Readme file.
Select the project file (hello.vbp) for this sample.  Click Open.

2. From the Run menu, select Start.