Character Animation Previoew (VB) Sample for Microsoft Agent V2
----------------------------------------------

*** Required components ***

This sample requires the Microsoft Agent Core Components,
version 2, the Microsoft Agent characters, and the Lernout & Hauspie� TruVoice Text-To-Speech Engine.
These should be installed before attempting to run this sample.


*** To run the sample ***

1. Start up Microsoft Visual Basic.  From the File menu, select
Open Project.  Navigate to the folder containing this Readme file.
Select the project file (Project1.vbp) for this sample.  Click Open.

2. Add the file, "frmAbout", to the project.

3. In the frmAbout form, set the icon property of the picture control to the charfile.ico icon file 

4. From the Run menu, select Start.