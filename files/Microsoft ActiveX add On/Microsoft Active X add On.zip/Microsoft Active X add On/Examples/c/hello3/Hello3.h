#ifndef _HelloAgent3_h_
#define _HelloAgent3_h_


#ifndef STRICT
#define STRICT
#endif


#include <windows.h>
#include <tchar.h>
#include "AgtSvr.h"


#endif
