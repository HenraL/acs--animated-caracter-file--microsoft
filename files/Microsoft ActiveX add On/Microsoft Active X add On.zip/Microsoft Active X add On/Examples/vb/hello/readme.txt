Hello World (VB) Sample for Microsoft Agent
-------------------------------------------

*** Required components ***

1. This sample requires the Microsoft Agent Core Components and the
TruVoice Text-To-Speech Engine.  These should be installed before
running this sample.

2. This sample reads character animations from the following
path: \Program Files\Microsoft Agent\Characters\.
The character animation file Genie.acs should be copied to that
location before running this sample.


*** To run the sample ***

1. Start up Microsoft Visual Basic.  From the File menu, select
Open Project.  Navigate to the folder containing this Readme file.
Select the project file (hello.vbp) for this sample.  Click Open.

2. From the Run menu, select Start.