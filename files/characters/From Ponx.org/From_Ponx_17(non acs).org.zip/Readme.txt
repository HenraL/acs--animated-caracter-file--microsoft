Welcome to Steve's Agent Refuge Camp on the web. I know we're a little hard to find in this
backwater, but that is the way some camp's are set up.

Here we have a few agents that are difficult to locate, or that have no known home on the net.  
Please excuse the spartan conditions, but we were hastily set up for the few disinfranchised 
agents that have come this way.  Those agents with money are asked to remain where they are, 
as some kind agenteer will come along and download them.

If you know of an agent in trouble, or who has no home, let us know, and we will find placement 
for them..either here, or over at Rick's Place. 